//
//  sdvgTests.swift
//  sdvgTests
//
//  Created by Nikita Sergeev on 27.06.2025.
//

import Testing
@testable import sdvg

struct sdvgTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
