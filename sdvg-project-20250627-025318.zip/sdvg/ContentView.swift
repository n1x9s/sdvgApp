//
//  ContentView.swift
//  sdvg
//
//  Created by Nikita Sergeev on 27.06.2025.
//

import SwiftUI

struct ContentView: View {
    @State private var showDragDrop = true
    @State private var alwaysOnTop = true
    
    var body: some View {
        VStack(spacing: 0) {
            // Заголовок
            HStack {
                Text("GIF Player")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Button(action: {
                    alwaysOnTop.toggle()
                    toggleAlwaysOnTop(alwaysOnTop)
                }) {
                    Image(systemName: alwaysOnTop ? "pin.fill" : "pin")
                        .foregroundColor(alwaysOnTop ? .blue : .secondary)
                }
                .buttonStyle(.plain)
                .help(alwaysOnTop ? "Отключить поверх всех окон" : "Включить поверх всех окон")
                
                Button(action: {
                    NSApplication.shared.terminate(nil)
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.secondary)
                }
                .buttonStyle(.plain)
                .help("Закрыть")
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color(NSColor.controlBackgroundColor))
            
            // Основная область
            Group {
                if showDragDrop {
                    DragDropGIFView()
                } else {
                    SimpleGIFView(gifName: "demo")
                        .background(Color.black.opacity(0.05))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .cornerRadius(8)
            .padding(8)
            
            // Нижняя панель
            HStack {
                Button(showDragDrop ? "Демо" : "Загрузить") {
                    showDragDrop.toggle()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                
                Spacer()
                
                Text("v1.0")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 8)
            .padding(.bottom, 8)
        }
        .frame(width: 300, height: 350)
        .background(Color(NSColor.windowBackgroundColor))
        .cornerRadius(12)
        .shadow(radius: 10)
        .onAppear {
            // Устанавливаем окно поверх всех при запуске
            toggleAlwaysOnTop(alwaysOnTop)
        }
    }
    
    private func toggleAlwaysOnTop(_ enabled: Bool) {
        DispatchQueue.main.async {
            if let window = NSApplication.shared.windows.first {
                window.level = enabled ? .floating : .normal
                window.collectionBehavior = enabled ? 
                    [.canJoinAllSpaces, .fullScreenAuxiliary] : 
                    [.canJoinAllSpaces]
            }
        }
    }
}

#Preview {
    ContentView()
}
